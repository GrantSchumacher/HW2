import java.io.BufferedReader;
import java.io.FileReader;
/**
 * CS2 HW2 
 * Borders.java 
 * Purpose: Used to identify that two countries border each other.
 * 
 * @author grantschumacher
 * @version 2.0 10/2/17 (1.0 was created 9/5/17)
 */


public class Borders {
	String[] borders;
	
	/**
	 * Constructor for Borders.java, number of borders must be specified for primitive arrays
	 * @param numberOfBorders
	 */
	public Borders(int numberOfBorders) {
		borders  = new String[numberOfBorders];
	}
	/**
	 * Adds the name of a country that borders at a given index
	 * @param index
	 * @param name
	 */
	public void addBorderCountry(int index, String name){
		borders[index] = name;
	}
	
	/**
	 * Gets the array of all borders specified for country
	 * @return
	 */
	public String[] getBorders(){
		return borders;
	}
	
	/**
	 * Prints names of all countries that border with specified country
	 */
	public void printBorders(){
		for(int i = 0; i < borders.length; i++){		
		System.out.println("  --" +borders[i]);
		}
	}
}
