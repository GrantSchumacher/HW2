import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * CS2 HW2 HW2.java Purpose: Imports data about countries from a text file and
 * enables the user to interact with the facts
 * 
 * @author grantschumacher
 * @version 1.0 9/5/17
 */
public class HW2 {

	String line = null;
	String input;
	Boolean quitProgram = false;
	
	//Create object of every required country
	Countries Germany = new Countries();
	Countries Netherlands = new Countries();
	Countries Belgium = new Countries();
	Countries Luxemburg = new Countries();
	Countries Poland = new Countries();
	Countries CzechRepublic = new Countries();
	Countries Austria = new Countries();
	Countries France = new Countries();
	Countries Switzerland = new Countries();

	//Create array and linked list of countries
	Countries[] countryArray = new Countries[9];
	LinkedList<Countries> countryLL = new LinkedList<Countries>();

	//Create scanner for user input
	Scanner sc = new Scanner(System.in);
	
	//Create border object for accessing Border.java methods
	Borders border = new Borders();

	public static void main(String[] args) {
		HW2 countryProject = new HW2();
		countryProject.addCountriesToArray();
		countryProject.addCountriesToLinkedList();
		countryProject.createUserInterface();
	}

	/**
	 * Greets the user, shows commands with assigned numbers, loops for amount of uses desired by user
	 */
	public void createUserInterface() {

		System.out.println("-------------------------------------------------------------------");
		System.out.println("Welcome. Please type in the number of the option you wish to choose:");
		System.out.println("1. Import the data");
		System.out.println("2. Dipslay list of countries that border Germany");
		System.out.println("3. Display list of all countries that have a population greater than 35 million");
		System.out.println("4. Display list of all countries that border Germany and have a population greater than 35 million");
		System.out.println("5. Quit the program");
		System.out.println("-------------------------------------------------------------------");

		while (quitProgram == false) {
			input = sc.next();
			switch (input) {
			case "1":
				System.out.println("What is the name of the file you wish to load?");
				input = sc.next();
				loadFileToArray(input);
				loadFileToLinkedList(input);
				System.out.println("-------------------------------------------------------------------");
				break;

			case "2":
				System.out.println("-------------------------------------------------------------------");
				System.out.println("The Countries that border with Germany are:");
				border.printBorders();
				System.out.println("-------------------------------------------------------------------");
				break;
				
			case "3":
				checkPopulation();
				break;
				
			case "4":
				checkBordersAndPopulation();
				break;
				
			case "5":
				System.out.println("Quitting Program");
				quitProgram = true;
				break;
				
			case "h":
				System.out.println("-------------------------------------------------------------------");
				System.out.println("1. Import the data");
				System.out.println("2. Dipslay list of countries that border Germany");
				System.out.println("3. Display list of all countries that have a population greater than 35 million");
				System.out.println(
						"4. Display list of all countries that border Germany and have a population greater than 35 million");
				System.out.println("5. Quit the program");
				System.out.println("-------------------------------------------------------------------");
				break;
			}
			if (quitProgram == false) { //Only prompt user to enter command if they wish to continue (quitProgram == false)
				System.out.println("Please enter your next command digit or type h to list them again:");
			} else { //Otherwise, closes the scanner and exits the loop
				sc.close();
				break;
			}
		}
	}
	
	/**
	 * Adds countries to countryArray
	 */
	public void addCountriesToArray() {
		countryArray[0] = Germany;
		countryArray[1] = Netherlands;
		countryArray[2] = Belgium;
		countryArray[3] = Luxemburg;
		countryArray[4] = Poland;
		countryArray[5] = CzechRepublic;
		countryArray[6] = Austria;
		countryArray[7] = France;
		countryArray[8] = Switzerland;
	}
	
	/**
	 * Adds countries to countryLL
	 */
	public void addCountriesToLinkedList() {
		countryLL.add(Germany);
		countryLL.add(Netherlands);
		countryLL.add(Belgium);
		countryLL.add(Luxemburg);
		countryLL.add(Poland);
		countryLL.add(CzechRepublic);
		countryLL.add(Austria);
		countryLL.add(France);
		countryLL.add(Switzerland);
	}

	/**
	 * Takes in user's file name and populates fields of every country in countryArray
	 * @param fileName
	 */
	public void loadFileToArray(String fileName) {

		try {

			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);

			// Retrieve countries information from file and populate country
			// array with data
			for (int i = 0; i < countryArray.length; i++) {
				countryArray[i].setCountryName(br.readLine());
				countryArray[i].setLatitude(br.readLine());
				countryArray[i].setLongitude(br.readLine());
				countryArray[i].setCountryArea(Integer.parseInt(br.readLine()));
				countryArray[i].setCountryPopulation(Integer.parseInt(br.readLine()));
				countryArray[i].setCountryGDP(Double.parseDouble(br.readLine()) * 1000000000);
				countryArray[i].setCountryYear(Integer.parseInt(br.readLine()));
				br.readLine();

			}
			br.close();
		} catch (Exception ex) {

			System.out.println("  --Failed to locate specified file:");
		}
	}
	/**
	 * Takes in user's file name and populates fields of every country in countryLL
	 * @param fileName
	 */
	public void loadFileToLinkedList(String fileName) {
		try {

			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);

			// Retrieve countries information from file and populate linked list
			// with data
			for (int x = 0; x < countryArray.length; x++) {
				countryLL.get(x).setCountryName(br.readLine());
				countryLL.get(x).setLatitude(br.readLine());
				countryLL.get(x).setLongitude(br.readLine());
				countryLL.get(x).setCountryArea(Integer.parseInt(br.readLine()));
				countryLL.get(x).setCountryPopulation(Integer.parseInt(br.readLine()));
				countryLL.get(x).setCountryGDP(Double.parseDouble(br.readLine()) * 1000000000);
				countryLL.get(x).setCountryYear(Integer.parseInt(br.readLine()));
				br.readLine();

			}

			br.close();
		} catch (Exception ex) {
			System.out.println(ex);

		}
	}
	/**
	 * Checks the population of every country in countryArray / countryLL and prints country name if population is > 35 million
	 */
	public void checkPopulation() {
		for (int i = 0; i < countryArray.length; i++) {
			if (countryArray[i].getCountryPopulation() > 35000000) {
				System.out.println("  --" + countryArray[i].getCountryName());
			}
		}
		// This is just to show that the same method could be implemented using
		// linked lists.
		/*
		 * for(int x = 0; x < countryLL.size(); x++){
		 * if(countryLL.get(x).getCountryPopulation() > 35000000){
		 * System.out.println("  --"+countryLL.get(x).getCountryName()); } }
		 */
	}
	
	/**
	 * Since all countries in this project border Germany it prints the countries with a population > 35 million excluding Germany 
	 */
	public void checkBordersAndPopulation() {
		for (int i = 0; i < countryArray.length; i++) {
			if (countryArray[i] != Germany) {
				if (countryArray[i].getCountryPopulation() > 35000000) {
					System.out.println("  --" + countryArray[i].getCountryName());
				}
			}
		}
	}
}
