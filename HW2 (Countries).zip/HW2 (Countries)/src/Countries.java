/**
 * CS2 HW2
 * Countries.java
 * Purpose: Creates a template class for countries
 * 
 * @author grantschumacher
 * @version 1.0 9/5/17
 */
public class Countries {
	private String countryName;
	private String latitude;
	private String longitude;
	private int countryArea;
	private int countryPopulation;
	private double countryGDP;
	private int countryYear;
	
	/**
	 * No argument constructor for the countries class
	 */
	public Countries(){
		countryName = "";
		latitude = "";
		longitude = "";
		countryArea = 0;
		countryPopulation = 0;
		countryGDP = 0;
		countryYear = 0;
	}
	
	/**
	 * Argument constructor for the countries class
	 * @param countryName
	 * @param latitude
	 * @param longitude
	 * @param countryArea
	 * @param countryPopulation
	 * @param countryGDP
	 * @param countryYear
	 */
	public Countries(String countryName, String latitude, String longitude, int countryArea, int countryPopulation, double countryGDP, int countryYear){
		countryName = this.countryName;
		latitude = this.latitude;
		longitude = this.longitude;
		countryArea = this.countryArea;
		countryPopulation = this.countryPopulation;
		countryGDP = this.countryGDP;
		countryYear = this.countryYear;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public int getCountryArea() {
		return countryArea;
	}

	public void setCountryArea(int countryArea) {
		this.countryArea = countryArea;
	}

	public int getCountryPopulation() {
		return countryPopulation;
	}

	public void setCountryPopulation(int countryPopulation) {
		this.countryPopulation = countryPopulation;
	}

	public double getCountryGDP() {
		return countryGDP;
	}

	public void setCountryGDP(double countryGDP) {
		this.countryGDP = countryGDP;
	}

	public int getCountryYear() {
		return countryYear;
	}

	public void setCountryYear(int countryYear) {
		this.countryYear = countryYear;
	}
}
