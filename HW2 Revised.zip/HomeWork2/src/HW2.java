import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Iterator;
import java.util.Scanner;

import org.w3c.dom.Node;
/**
 * CS2 HW2 
 * HW2.java 
 * Purpose: Takes in user commands, prints and analyzes country data based off of commands.
 * 
 * @author grantschumacher
 * @version 2.0 10/2/17 (1.0 was created 9/5/17)
 */
public class HW2 {

	String line = null;
	String input;
	Boolean quitProgram = false;

	//Create array and linked list of countries
	Countries[] countryArray = new Countries[9];
	LinkedList countryLL = new LinkedList();
	
	//Create scanner for user input
	Scanner sc = new Scanner(System.in);
	
	//Create border object for accessing Border.java methods
	Borders germanyBorders = new Borders(9);
	
	public static void main(String[] args) {
		HW2 countryProject = new HW2();
	
		countryProject.createUserInterface();
	}

	/**
	 * Greets the user, shows commands with assigned numbers, loops for amount of uses desired by user
	 */
	public void createUserInterface() {

		System.out.println("-------------------------------------------------------------------");
		System.out.println("Welcome. Please type in the number of the option you wish to choose:");
		System.out.println("1. Import the data");
		System.out.println("2. Dipslay list of countries that border Germany");
		System.out.println("3. Display list of all countries that have a population greater than 35 million");
		System.out.println("4. Display list of all countries that border Germany and have a population greater than 35 million");
		System.out.println("5. Quit the program");
		System.out.println("-------------------------------------------------------------------");

		while (quitProgram == false) {
			input = sc.next();
			switch (input) {
			case "1":
				System.out.println("What is the name of the file you wish to load?");
				input = sc.next();
				loadFileToLists(input);
				
				System.out.println("-------------------------------------------------------------------");
				break;

			case "2":
				System.out.println("-------------------------------------------------------------------");
				System.out.println("The Countries that border with Germany are:");
				germanyBorders.printBorders();
				System.out.println("-------------------------------------------------------------------");
				break;
				
			case "3":
				checkPopulation();
				break;
				
			case "4":
				checkBordersAndPopulation();
				break;
				
			case "5":
				System.out.println("Quitting Program");
				quitProgram = true;
				break;
				
			case "h":
				System.out.println("-------------------------------------------------------------------");
				System.out.println("1. Import the data");
				System.out.println("2. Dipslay list of countries that border Germany");
				System.out.println("3. Display list of all countries that have a population greater than 35 million");
				System.out.println("4. Display list of all countries that border Germany and have a population greater than 35 million");
				System.out.println("5. Quit the program");
				System.out.println("-------------------------------------------------------------------");
				break;
			}
			if (quitProgram == false) { //Only prompt user to enter command if they wish to continue (quitProgram == false)
				System.out.println("Please enter your next command digit or type h to list them again:");
			} else { //Otherwise, closes the scanner and exits the loop
				sc.close();
				break;
			}
		}
	}


	/**
	 * Takes in user's file name and populates fields of every country in countryArray
	 * @param fileName
	 */
	public void loadFileToLists(String fileName) {

		try {

			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			
			// Retrieve countries information from file and populate country
			// array with data
			
			for (int i = 0; i < countryArray.length; i++) {
				String name = br.readLine();
				name = name.replaceAll("\\s+", "");
				String latitude = br.readLine();	
				String longitude = br.readLine();				
				int area = Integer.parseInt(br.readLine());			
				int population = Integer.parseInt(br.readLine());
				double GDP = Double.parseDouble(br.readLine())* 1000000000;
				int year = Integer.parseInt(br.readLine());
				germanyBorders.addBorderCountry(i, name); //Adds bordering countries of Germany
				countryArray[i] = new Countries(name, latitude, longitude, area, population, GDP, year); //Populates country at index i
				countryLL.add(new Countries(name, latitude, longitude, area, population, GDP, year)); //Populates country and appends to linked list
				
			}
			
			br.close();
		} catch (Exception ex) {

			System.out.println("  --Failed to locate specified file");
			System.out.println(ex);
		}
	}
	
	/**
	 * Checks the population of every country in countryArray / countryLL and prints country name if population is > 35 million
	 */
	public void checkPopulation() {
		for (int i = 0; i < countryArray.length; i++) {
			if (countryArray[i].getCountryPopulation() > 35000000) {
				System.out.println("  --" + countryArray[i].getCountryName());
			}
		}
	}
	
	
	/**
	 * Prints the countries with a population > 35 million that border Germany
	 */
	public void checkBordersAndPopulation() {
		for (int i = 0; i < countryArray.length; i++) {
			if(countryArray[0].getCountryName() != "Germany"){
				if (countryArray[i].getCountryPopulation() > 35000000) { 
					System.out.println("  --" + countryArray[i].getCountryName());
				}
			}
		}
	}
	
	/**
	 * Hand written linked list class. Disclaimer: A tutorial was followed to make the following class
	 * @author grantschumacher
	 *
	 */
	public class LinkedList{
		private Node head;
		private int listCount;
		
		/**
		 * No argument Constructor
		 */
		public LinkedList(){
			head = new Node(null);
			listCount = 0;
		}
		
		/**
		 * Appends the Object data to the linked list
		 * @param data
		 */
		public void add(Object data){
			Node temp = new Node(data);
			Node current = head;
			
			while(current.getNext() != null){
				current = current.getNext();
			}
			
			current.setNext(temp);
			listCount++;
		}
		
		/**
		 * returns the size of the linked list
		 * @return
		 */
		public int size(){
			return listCount;
		}
		
		/**
		 * gets and returns object at specified index in linked list
		 * @param index
		 * @return
		 */
		public Object get(int index){
			if(index <= 0){
				return null;
			}
			Node current = head.getNext();
			
			for(int i = 1; i < index; i++){
				if(current.getNext() == null){
					return null;
				}
				current = current.getNext();
			}
			return current.getData();
		}
	}
	
	/**
	 * Node class to be implemented by LinkedList
	 * @author grantschumacher
	 *
	 */
	private class Node{
		Node next;
		Object data;
		
		/**
		 * No argument contstructor
		 * @param data
		 */
		public Node(Object data){
			this.data = data;
			next = null;
		}
		
		/**
		 * Constructor for Node class
		 * @param data
		 * @param next
		 */
		public Node(Object data, Node next){
			this.next = next;
			this.data = data;
		}
		
		/**
		 * Gets object at specified node
		 * @return
		 */
		public Object getData(){
			return data;
		}
		
		/**
		 * Sets object at specified Node
		 * @param data
		 */
		public void setData(Object data){
			this.data = data;
		}
		
		/**
		 * Gets location of next node
		 * @return
		 */
		public Node getNext(){
			return next;
		}
		
		/**
		 * Sets location of next node
		 * @param next
		 */
		public void setNext(Node next){
			this.next = next;
		}
	}
	
}
