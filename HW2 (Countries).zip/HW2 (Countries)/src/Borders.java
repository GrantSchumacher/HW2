
/**
 * CS2 HW2 Borders.java Purpose: Used to identify if two countries border each
 * other
 * 
 * @author grantschumacher
 * @version 1.0 9/5/17
 */
public class Borders {

	String[] germanyArray = new String[8];
	/**
	 * No argument constructor for Borders.java
	 */
	public Borders() {

	}
	
	/**
	 * Prints the borders of Germany (All items in germanyArray) to the console
	 */
	public void printBorders() {
		addCountries();
		for (int i = 0; i < germanyArray.length; i++) {
			System.out.println("  --" + germanyArray[i]);
		}
	}
	/**
	 * Populates germanyArray with all countries that border Germany
	 */
	private void addCountries() {
		germanyArray[0] = "Netherlands";
		germanyArray[1] = "Belgium";
		germanyArray[2] = "Luxembourg";
		germanyArray[3] = "Poland";
		germanyArray[4] = "CzechRepublic";
		germanyArray[5] = "Austria";
		germanyArray[6] = "France";
		germanyArray[7] = "Switzerland";

	}
}
