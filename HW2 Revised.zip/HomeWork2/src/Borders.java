import java.io.BufferedReader;
import java.io.FileReader;

//THIS IS A COPY


public class Borders {
	String[] borders;
	
	/**
	 * No argument constructor for Borders.java
	 */
	public Borders(int numberOfBorders) {
		borders  = new String[numberOfBorders];
	}
	public void addBorderCountry(int index, String name){
		borders[index] = name;
	}
	public String[] getBorders(){
		return borders;
	}
	public void printBorders(){
		for(int i = 0; i < borders.length; i++){		
		System.out.println("  --" +borders[i]);
		}
	}
}
